Sistema de gestion bibliotecaria academico

Para la creacion de la base de datos tener en cuenta los siguientes parametros:
 - Nombre de la base de datos: BIBLIOTECA
 - Constraseña: bibliotecaweb

Para el primer ingreso al sistema:
 - usuario: admin
 - contraseña: admin


